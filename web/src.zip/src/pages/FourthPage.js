import React from 'react';

const FourthPage = ({ images, onGoBack, onReset }) => {
  const handleGoBack = () => {
    onGoBack('third');
  };
  
  const handleReset = () => {
    onReset();
  };

  return (
    <div>
      <h2>Result Images</h2>
      {images && images.length > 0 ? (
        <div>
          {images.map((encodedImage, index) => (
            // eslint-disable-next-line jsx-a11y/img-redundant-alt
            <img
              key={index}
              src={`data:image/png;base64,${encodedImage}`}
              alt={`Image ${index + 1}`}
              style={{ maxWidth: '300px', margin: '10px' }}
            />
          ))}
        </div>
      ) : (
        <p>No analysis result images found.</p>
      )}
      <button onClick={handleGoBack}>back</button>
      <button onClick={handleReset}>reset</button>
    </div>
  );
};

export default FourthPage;
