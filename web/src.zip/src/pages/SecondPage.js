import React, { useState } from 'react';
import axios from 'axios';
import styles from "./SecondPage.module.css";

const SecondPage = ({ category, text, modifiedText, modifiedWords, onGoBack, onContinue}) => {
  const [SecondModifiedText, setSecondModifiedText] = useState(modifiedText);

  const handleTextChange = (event) => {
    setSecondModifiedText(event.target.value);
  };

  const handleGoBack = () => {
    onGoBack('first');
  };
  
  const handleContinue = () => {
    if (SecondModifiedText.trim().length > 0) {
      
      axios.post('http://127.0.0.1:5000/react_to_flask_2', {
        SecondModifiedText: SecondModifiedText, 
      },{
        headers: {
          'Content-Type': 'application/json'
        }
      })
      
      .then((response) => {

        console.log(response.data);

        const analysisResult = response.data.analysisResult;
        const image = response.data.image;

        console.log(analysisResult)
        console.log(image)

        onContinue(SecondModifiedText, analysisResult, image);
      })
      .catch((error) => {
        console.error('Error while sending data to the server:', error);
      });
    } else {
      alert('Please select a category and enter the text.');
    }
  };


  return (
    <div className={styles.secondpage}>
      <div className={styles.secondpage_top_wrapper}>
        <div className={styles.secondpage_top}>
          <p className={styles.secondpage_title}>엣헴.. 맞춤법은 기본 중의 기본이라네</p>
          <img src='./훈장님_맞춤법.png' className={styles.secondpage_logo}></img>
        </div>
      </div>
      <div className={styles.secondpage_mid}>
        <button className={styles.secondpage_btn} onClick={handleGoBack}>◀이전</button>
        <div className={styles.before}>
          <p className={styles.text_title}>원본</p>
          <p className={styles.before_text}>{text}</p> 
        </div>
        <div className={styles.after}>
          <p className={styles.text_title}>맞춤법 교정 글 (바꿀 수 있음)</p>
          <textarea  className={styles.secondpage_text} value={SecondModifiedText} onChange={handleTextChange} />
        </div>
        <button className={styles.secondpage_btn} onClick={handleContinue}>다음▶</button>
      </div>
      <div className={styles.secondpage_bot_wrapper}>
        <div className={styles.secondpage_bot}>
          {modifiedWords ? (
              <p className={styles.secondpage_msg}>수정한 단어 : {modifiedWords.join(', ')}</p>
          ) : (
            <p className={styles.secondpage_msg}>맞춤법 고수군요! 수정할 단어가 없습니다.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default SecondPage;
