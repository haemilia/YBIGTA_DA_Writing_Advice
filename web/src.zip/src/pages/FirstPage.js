import React, { useState } from 'react';
import axios from 'axios';
import CategorySelection from '../components/CategorySelection';
import styles from "./FirstPage.module.css";

const FirstPage = ({ onContinue }) => {
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [text, setText] = useState('');

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
  };

  const handleTextChange = (event) => {
    setText(event.target.value);
  };

  const handleContinue = () => {
    if (selectedCategory && text.trim().length > 0) {
      axios.post('http://127.0.0.1:5000/react_to_flask_1', {
        category: selectedCategory,
        text: text,
      },{
        headers: {
          'Content-Type': 'application/json'
        }
      })
      
      .then((response) => {
        console.log(response.data);

        const FirstModifiedText = response.data.modifiedText;
        const modifiedWords = response.data.modifiedWords;

        console.log(FirstModifiedText)
        console.log(modifiedWords)

        onContinue(selectedCategory, text, FirstModifiedText, modifiedWords);
      })
      .catch((error) => {
        console.error('Error while sending data to the server:', error);
      });
    } else {
      alert('Please select a category and enter the text.');
    }
  };

  return (
    <div className={styles.firstpage}>
      <div className={styles.firstpage_top}>
        <p className={styles.category_title}>엣헴.. 글을 작성하고 제출해보거라</p>
        <img src='./훈장님_로고.png' className={styles.firstpage_logo}></img>
      </div>
      <div className={styles.firstpage_bot}>
      <CategorySelection onChange={handleCategoryChange} />
      <br></br>
      <textarea className={styles.firstpage_text} placeholder="여기다가 글을 쓰시오" value={text} onChange={handleTextChange}  />
      <button className={styles.firstpage_button} onClick={handleContinue}>제출!</button>
      </div>
    </div>
  );
};

export default FirstPage;
