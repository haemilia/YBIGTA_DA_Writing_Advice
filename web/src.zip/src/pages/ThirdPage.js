/* eslint-disable react/jsx-no-comment-textnodes */
/* eslint-disable jsx-a11y/alt-text */
import React from 'react';
import styles from "./ThirdPage.module.css";

const ThirdPage = ({ analysisResult, images, onGoBack, onReset }) => {
  const handleGoBack = () => {
    onGoBack('second');
  };
  
  const handleReset = () => {
    onReset();
  };

  return (
    <div className={styles.thirdPage}>
      <div className={styles.thirdpage_top_wrapper}>
        <div className={styles.thirdpage_top}>
          <p className={styles.thirdpage_title}>떼잉.. 글 공부에 매진하도록</p>
          <img src='./훈장님_결과.png' className={styles.thirdpage_logo}></img>
        </div>
      </div>
      <div className={styles.thirdpage_mid_wrapper}>
        {images.map((encodedImage, index) => (
          <div key={index} className={styles.thirdpage_mid}>
            <img
              src={`data:image/png;base64,${encodedImage}`}
              className={styles.thirdpage_img}
            />
            <p className={styles.thirdpage_msg}>{analysisResult[index]}</p>
          </div>
        ))}
      </div>
      <div className={styles.btn_wrapper}>
        <button className={styles.thirdpage_btn} onClick={handleGoBack}>이전</button>
        <button className={styles.thirdpage_btn} onClick={handleReset}>초기화</button>
      </div>
    </div>
  );
};

export default ThirdPage;