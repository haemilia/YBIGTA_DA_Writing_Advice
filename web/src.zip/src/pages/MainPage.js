import React from 'react';
import { useState, useEffect } from 'react';
import styles from "./MainPage.module.css";

const MainPage = ({ onContinue }) => {
  const handleContinue = () => {
    onContinue('first');
  }

  return (
    <div className={styles.mainpage}>
      <img src="./훈장님_시작.jpeg" className={styles.mainpage_img}/>
      <p className={styles.mainpage_title}>
      <span className={styles.big}>훈</span>
        <span className={styles.small}>수하는</span>
        <span className={styles.big}>장</span>
        <span className={styles.small}>인</span>
        <span className={styles.big}>님</span>
      </p>
      <button onClick={handleContinue} className={styles.mainpage_btn}>시작!</button>
    </div>
  );
};

export default MainPage;
