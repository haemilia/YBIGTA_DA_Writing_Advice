import React, { useState } from 'react';
import FirstPage from './pages/FirstPage';
import SecondPage from './pages/SecondPage';
import ThirdPage from './pages/ThirdPage';
import MainPage from './pages/MainPage';

const App = () => {
  const [currentPage, setCurrentPage] = useState('main');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [text, setText] = useState('');
  const [modifiedText, setModifiedText] = useState('');
  const [modifiedWords, setModifiedWords] = useState('')
  const [analysisResult, setAnalysisResult] = useState('');
  const [images, setImages] = useState('');
  const [imageText, setImageText] = useState('');

  const handleContinueToSecondPage = (selectedCategory, text, FirstModifiedText, modifiedWords) => {
    setSelectedCategory(selectedCategory);
    setText(text);
    setModifiedText(FirstModifiedText);
    setModifiedWords(modifiedWords);
    setCurrentPage('second');
  }; 

  const handleContinueToThirdPage = (SecondModifiedText, analysisResult, image, text) => {
    setModifiedText(SecondModifiedText);
    setAnalysisResult(analysisResult);
    setImages(image);
    setImageText(text)
    setCurrentPage('third');
  };

  const handleGoBack = (page) => {
    setCurrentPage(page);
  };

  const handleReset = () => {
    setCurrentPage('main');
    setSelectedCategory(null);
    setText('');
    setModifiedText('');
    setAnalysisResult('');
    setImages(null);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'main' :
        return(
          <MainPage
            onContinue={handleGoBack}
          />
        );
      case 'first':
        return (
          <FirstPage 
            onContinue={handleContinueToSecondPage}
          />
        );
      case 'second':
        return (
          <SecondPage
            category={selectedCategory}
            text={text}
            modifiedText={modifiedText}
            modifiedWords={modifiedWords}
            onGoBack={handleGoBack}
            onContinue={handleContinueToThirdPage}
          />
        );
      case 'third':
        return (
          <ThirdPage
            analysisResult={analysisResult}
            images = {images}
            imageText = {imageText}
            onGoBack={handleGoBack}
            onReset={handleReset}
          />
        );
      default:
        return null;
    }
  };

  return <div className="App">{renderPage()}</div>;
};

export default App;
