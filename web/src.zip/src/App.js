import React, { useState } from 'react';
import FirstPage from './pages/FirstPage';
import SecondPage from './pages/SecondPage';
import ThirdPage from './pages/ThirdPage';
import FourthPage from './pages/FourthPage';
import MainPage from './pages/MainPage';

const App = () => {
  const [currentPage, setCurrentPage] = useState('main');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [text, setText] = useState('');
  const [modifiedText, setModifiedText] = useState('');
  const [modifiedWords, setModifiedWords] = useState('')
  const [analysisResult, setAnalysisResult] = useState('');
  const [images, setImages] = useState('');

  const handleContinueToSecondPage = (selectedCategory, text, FirstModifiedText, modifiedWords) => {
    setSelectedCategory(selectedCategory);
    setText(text);
    setModifiedText(FirstModifiedText);
    setModifiedWords(modifiedWords);
    setCurrentPage('second');
  }; 

  const handleContinueToThirdPage = (SecondModifiedText, analysisResult, image) => {
    setModifiedText(SecondModifiedText);
    setAnalysisResult(analysisResult);
    setImages(image);
    setCurrentPage('third');
  };

  const handleContinueToFourthPage = () => {
    setCurrentPage('fourth');
  };

  const handleGoBack = (page) => {
    setCurrentPage(page);
  };

  const handleReset = () => {
    setCurrentPage('first');
    setSelectedCategory(null);
    setText('');
    setModifiedText('');
    setAnalysisResult('');
    setImages(null);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'main' :
        return(
          <MainPage
            onContinue={handleGoBack}
          />
        );
      case 'first':
        return (
          <FirstPage 
            onContinue={handleContinueToSecondPage}
          />
        );
      case 'second':
        return (
          <SecondPage
            category={selectedCategory}
            text={text}
            modifiedText={modifiedText}
            modifiedWords={modifiedWords}
            onGoBack={handleGoBack}
            onContinue={handleContinueToThirdPage}
          />
        );
      case 'third':
        return (
          <ThirdPage
            originalText={text}
            modifiedText={modifiedText}
            analysisResult={analysisResult}
            onGoBack={handleGoBack}
            onContinue={handleContinueToFourthPage}
          />
        );
      case 'fourth':
        return (
          <FourthPage
            images = {images}
            onGoBack={handleGoBack}
            onReset={handleReset}
          />
        );
      default:
        return null;
    }
  };

  return <div className="App">{renderPage()}</div>;
};

export default App;
