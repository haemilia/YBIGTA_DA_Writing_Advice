base_url = 'https://m.search.naver.com/p/csearch/ocontent/util/SpellerProxy'


class CheckResult:
    PASSED = 0
    WRONG_SPELLING = 1
    WRONG_SPACING = 2
    AMBIGUOUS = 3
    STATISTICAL_CORRECTION = 4

